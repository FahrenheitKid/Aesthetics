Nome: Jordan Silva

Features Implementadas:

- Leitura e Criação do mapa a partir de um .txt.
- Colorização do Grid conforme jogadores se movimentam.
- Itens que marcam pontos spawnam periodicamente (aka ScoreMakers).
- ScoreMakers pontuam a quantidade de tiles da cor do jogador no momento que ele é pego e também limpa os tiles.
- Jogabildiade e Input para 2 Jogadores.


Comandos:
Player 1 - WASD
Player 2 - Arrow Keys
Q e E - Rotaciona a camera.
ESC - Fecha o jogo
R - Reinicia o jogo