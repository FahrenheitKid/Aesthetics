﻿Nome: Jordan Silva



Comandos:

Player 1:

Movimentação -  WASD

Ação - SPACE BAR/ Z

Player 2:

Movimentação - Arrow Keys

Ação - RIGHT CTRL/ RIGHT SHIFT

ESC - Fecha o jogo

R - Reinicia o jogo




Items:


{Lock} (Passivo, Duradouro): É um cadeado que ao ser coletado faz com que todos os {tiles} do jogador em questão fiquem imunes aos oponentes, ou seja, não podem ser pintados por nenhum outro jogador.


{Arrow} (Passivo, Instantâneo): É uma seta que aponta para alguma das quatro direções. Ela pode girar de tempos em tempos, alterando a sua direção. Ao ser coletada, todos os {tiles} na direção apontada são pintados com a cor do jogador em questão. Existem três variações desse item: Um que aponta apenas para uma direção (norte, sul, leste ou oeste); aponta para duas direções opostas (norte-sul, leste-oeste); aponta para todas as 4 direções.


{V Ray} (Ativo, Instantâneo): Um raio em orientação vertical que ao ser ativado projeta dois raios lasers que saem a partir do jogador e atingem toda a coluna que ele estiver no momento. Os adversários que forem acertados pelo raio são atordoados por um período de tempo.


{H Ray} (Ativo, Instantâneo): Funciona assim como o {V Ray} porém os raios são lançados na horizontal.


{Revolver} (Ativo, Instantâneo): Uma pistola que ao ser ativada o jogador entra num modo de "mira", onde a proxima direção que ele pressionar nos controles será a direção que o tiro será lançado. Após entrar no modo "mira" o jogador pode dar o tiro assim que desejar, logo em seguida ou pode esperar um tempo até que algum alvo se aproxime. O tiro atinge o primeiro adversário que estiver no seu caminho, atordoando-o e roubando os {tiles} daquele jogador, convertendo sua cor para a cor referente ao jogador que deu o disparo.


{Rainbow Lipstick} (Passivo, Duradouro): Um batom colorido que ao ser coletado faz com que as cores do jogador se tornem as cores dos seus adversários. Porém elas mudam apenas como um disfarce, ainda contando para a pontuação do usuário do batom. Com os {tiles} disfarçados, os adversários não terão certeza de quais deles realmente são pertencentes à eles e poderão evitar de pintar sobre os {tiles} do usuário do item.


{FastFoward} (Passivo, Duradouro): Tem aparência de um ícone de {FastFoward} característico de dispositivos de áudio. Ao ser coletado acelera o ritmo da música por um determinado período.


{SloMo} (Passivo, Duradouro): Atua da mesma forma que o {FastFoward} porém desacelerando a melodia.


{Sneakers} (Passivo, Duradouro): Um par de sapatos que permite ao jogador mover-se dois {tiles} por movimento ao invés de um. Ele pinta todos os tiles que passar durante seus movimentos.


{Floppy Disk} (Passivo, Duradouro): Um pequeno disquete que funciona como um escudo para o jogador. Assim que qualquer efeito negativo fosse acontecer com ele, o disquete é automaticamente usado e descartado, concedendo imunidade por um curto período de tempo.


{Compact Disk} (Ativo, Duradouro): Um CD que atua de forma semelhante ao Disquete, porém é um item Ativo. Quando acionado concede ao jogador imunidade por um período equivalente à seis vezes o valor de seu {Multiplicador}.


{3D Glasses} (Passivo, Instantâneo): Um óculos que no momento que é pego faz com que a câmera gire 90 graus, mudando a perspectiva do jogo, além de aumentar o {Multiplicador} do jogador em 3.